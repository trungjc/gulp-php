<?php include('includes/header.php') ?>

<body>
  <?php include('includes/content.php') ?>
  <!--build:js assets/js/main.min.js -->
  <script src="assets/js/lib/a-library.js"></script>
  <script src="assets/js/lib/another-library.js"></script>
  <script src="assets/js/main.js"></script>
  <!-- endbuild -->
</body>

</html>
